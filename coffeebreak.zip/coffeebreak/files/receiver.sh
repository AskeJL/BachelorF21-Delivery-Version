#!/bin/bash

gst-launch-1.0 -e udpsrc port=8080 ! 'application/x-rtp, media=(string)audio, clock-rate=(int)8000, encoding-name=(string)L24, encoding-params=(string)1, channels=(int)1' ! rtpL24depay ! audioconvert ! wavenc ! filesink location=./test_received.wav



gst-launch-1.0 -e udpsrc port=49153 ! 'application/x-rtp, media=(string)audio, clock-rate=(int)44100, encoding-name=(string)L24, encoding-params=(string)1, channels=(int)1' ! rtpjitterbuffer ! rtpL24depay ! audioconvert ! fakesink sync=false


kubectl exec --stdin --tty shell-demo -- /bin/bash

gst-launch-1.0 -e udpsrc port=7000 ! audioconvert ! rtpL24pay ! udpsink host=0.0.0.0 port=49153 

send videre til gateway:
gst-launch-1.0 -e udpsrc port=49153 ! udpsink host=0.0.0.0 port=7089

Send til anden gstreamer

gst-launch-1.0 -e udpsrc port=7000 ! udpsink host=172.17.0.6 port=49153

userpod 172.17.0.4
userpod2 172.17.0.6
userpod3 172.17.0.7