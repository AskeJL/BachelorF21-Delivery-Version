#!/bin/bash

send 1 file :
gst-launch-1.0 -v filesrc location=./test.wav ! wavparse ! audioconvert ! rtpL24pay ! udpsink host=0.0.0.0 port=49153

send 1 file:
gst-launch-1.0 -v audiotestsrc freq=100 ! audioconvert ! rtpL24pay ! udpsink host=172.17.0.16 port=49153

Send to different hosts:
gst-launch-1.0 -v filesrc location=./test.wav ! wavparse ! audioconvert ! rtpL24pay ! tee name=t t. ! udpsink host=172.17.0.8 port=49153 t. ! udpsink host=172.17.0.9 port=49153 t. ! udpsink host=172.17.0.10 port=49153 t. ! udpsink host=172.17.0.11 port=49153 t. ! udpsink host=172.17.0.12 port=49153 t. ! udpsink host=172.17.0.13 port=49153 t. ! udpsink host=172.17.0.14 port=49153 t. ! udpsink host=172.17.0.15 port=49153 t. ! udpsink host=172.17.0.16 port=49153 t. ! udpsink host=172.17.0.17 port=49153 t. ! udpsink host=172.17.0.18 port=49153 


send lyd til lydkort: 
gst-launch-1.0 filesrc location=test.wav ! wavparse ! audioconvert ! audioresample ! autoaudiosrc

Mix sound:
gst-launch-1.0 audiotestsrc freq=100 ! audiomixer name=mix ! audioconvert ! alsasink audiotestsrc freq=500 ! mix.

gst-launch-1.0 audiomixer name=mix! filesrc location=./test.wav ! wavparse ! audioconvert ! mix. filesrc location=./pow.wav ! waveparse ! audioconvert ! mix. ! filesink location=./mix_test.wav